Holmes: The Crooked Man
(C) Copyright 2015 Erik Ridd

Based on the short story by Sir Arthur Conan Doyle. Song "Anamalie" from
incompetech.com.

